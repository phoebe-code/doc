path(path,'../Classes')
path(path,'../IterativeMethods')
path(path,'../DirectMethods')
path(path,'../TestData')
