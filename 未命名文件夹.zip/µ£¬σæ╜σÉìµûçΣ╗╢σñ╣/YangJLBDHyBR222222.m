function [x_out, output] = YangJLBDHyBR222222(A, L, b,x_true, maxiter)
%
% [x_out, flag, relres, iter, output] = YangIterJLBD(A, b, P, options)
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% call by means of the following way
% options== HyBRset('InSolv', 'tikhonov', 'RegPar', 'gcv', 'x_true', x_true(:),'Iter', maxit);
%
% [x_out, flag, relres, iter, output] = YangJLBDHyBR(A, L, b, [], options)
%
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% Outputs:
%      x_out : computed solution
%     output : structure with the following fields:
%      iterations - stopping iteration (options.Iter | GCV-determined)
%         GCVstop - GCV curve used to find stopping iteration
%            Enrm - relative error norms (requires x_true)
%            Rnrm - relative residual norms
%            Xnrm - relative solution norms
%             U,V - Lanczos basis vectors
%               B - bidiagonal matrix from LBD
%            flag - a flag that describes the output/stopping condition:
%                       1 - flat GCV curve
%                       2 - min of GCV curve (within window of 4 its)
%                       3 - performed max number of iterations

%% Initialization
% 
% A = sparse(A); 
[~,n] = size(L);
nrmtrue = norm(L*x_true);


[BB, BBbar, UU, ~, VV, bbeta]=JointBid(A,L,b,maxiter,2);
h = waitbar(0, 'Beginning iterations: please wait ...');
for i = 1:maxiter %Iteration (i=1) is just an initialization
    
    %     [U, Uhat, B, Bbar, Bhat, V] = feval(handle, A, L, U, Uhat, B, Bbar, Bhat, V, 1);
    
    %    [U, Uhat, B, Bbar, Bhat, V, flag, relres, iter] = YangJLBD(A, L, U, Uhat, B, Bbar, Bhat, V, 0);
    
    U = UU(:,1:i+1); V = VV(:,1:i);
    B = BB(1:i+1,1:i); Bbar = BBbar(1:i,1:i);
    vector = (bbeta*eye(size(U,2),1));
    
    
    
    if i >= 1 %Begin Lanczos iterations
        
        
        f = B\vector;
        d = V*f;
        x = lsqr(@(z,tflag)afun(z,A,L,tflag),d,1e-6,n);
        x_out(:,i) = x;
        output.Rnrm(i,1) = norm(B*f-vector);
        output.Xnrm(i,1) = norm(Bbar*f);
        output.err(i,1) = norm(L*(x-x_true))/nrmtrue;
        
    end
    
    
        
        
    waitbar(i/(maxiter+1), h)
end
% [reg_c,rho_c,eta_c] = l_corner(output.Rnrm,output.Xnrm);
%         plot_lc(output.Rnrm,output.Xnrm,'o',2);
%         ax = axis;hold on
%         loglog([min(output.Rnrm)/100,rho_c],[eta_c,eta_c],':r',...
%             [rho_c,rho_c],[min(output.Xnrm)/100,eta_c],':r')
%         title(['L-curve, ','tsvd',' corner at ',num2str(reg_c)]);
%         axis(ax)
%         hold off
close(h)
end
function y =afun(z,A,B,transp_flag)
if strcmp(transp_flag,'transp')   % y = (A(I_n-BB^T))' * z;
    m = size(A,1);
    p = size(B,1);
    s = A'*z(1:m);
    t = B'*z(m+1:m+p);
    y = s + t;
elseif strcmp(transp_flag,'notransp') % y = (A(I_n-BB^T)) * z;
    s = A*z;
    t= B*z;
    y = [s;t];
    
end
end


