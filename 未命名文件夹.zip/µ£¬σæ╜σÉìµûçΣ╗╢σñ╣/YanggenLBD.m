function [U, B, V] = YanggenLBD(A, U, B, V, P)
%
%     [U, B, V] = LBD(A, U, B, V, P, options)
%
%  Perform one step of Lanczos bidiagonalization with or without
%  reorthogonalization, WITHOUT preconditioner here.
%
% Input:
%          A - matrix
%       U, V - accumulation of vectors
%          B - bidiagonal matrix
% P_le, P_ri - input ignored
%    options - structure from HyBR (see HyBRset)
%
% Output:
%       U, V - updated "orthogonal" matrix
%          B - updated bidiagonal matrix
%
%  Refs:
%   [1] Paige and Saunders, "LSQR an algorithm for sparse linear
%       equations an sparse least squares", ACM Trans. Math Software,
%       8 (1982), pp. 43-71.
%   [2] Bjorck, Grimme and Van Dooren, "An implicit shift bidiagonalization
%       algorithm for ill-posed systems", BIT 34 (11994), pp. 520-534.
%
%   J.Chung and J. Nagy 3/2007

% Determine if we need to do reorthogonalization or not.

n = size(A,1);
m = size(U,1);
k = size(B,2)+1;


if k == 1
    v = lsqr(@(z,tflag)afun(z,P',P,tflag), A'*U(:,k),1e-8,n);
else
    vv = A'*U(:,k) - B(k, k-1)* (P'* P) * V(:,k-1);
    v = lsqr(@(z,tflag)afun(z,P',P,tflag), vv,1e-8,n);
    for j = 1:k-1
        v = v - ((P*V(:,j))'*v)* P*V(:,j);
    end
end
alpha = v'*(P'*P)*v;
v = P*v/alpha;
u = A*v - alpha*U(:,k);
for j = 1:k
    u = u - (U(:,j)'*u)*U(:,j);
end
beta = norm(u);
u = u / beta;
U = [U, u];
V = [V, v];
B = [B, [zeros(k-1,1); alpha]; [zeros(1,k-1), beta]];
end

function y =afun(z,A,B,transp_flag)
if strcmp(transp_flag,'transp')   % y = (A(I_n-BB^T))' * z;
    s = A'*z;
    y = B'*s;
elseif strcmp(transp_flag,'notransp') % y = (A(I_n-BB^T)) * z;
    t = B*z;
    y = A*t;  
end
end