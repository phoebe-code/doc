clc;
clear all;
close all;


maxit = 10;
% %%%%%%%%%%%%%%%%%%%%%%%% 1D %%%%%%%%%%%%%%%%%%%%%%%%%%%
% n = 3000;
% [A,btrue,x_true] = deriv2(n,2);
% 
% delta = 0.1;
% e =  randn(size(btrue))/norm(randn(size(btrue)));
% e = norm(btrue)*delta*e;
% b = btrue + e;
% % ddelta1 = 0.5*norm(e);
% % ddelta2 = 1.1*norm(e);
% % ddelta3 = 1.2*norm(e);
% % ddelta4 = 2.0*norm(e);
% 
% L = get_l(n,1);
% % 
% %%%%%%%%%%%%%%%%%%%%%%%%% 2D %%%%%%%%%%%%%%%%%%%%%%%%%% 
N = 256;
% A = blur(N,16,2);
% xt=imread('rice.png'); 
% load mri
% x_true = double(D(1:N,1:N,15));
load GaussianBlur422
% load VariantMotionBlur_large
% load AtmosphericBlur30
% A = psfMatrix(PSF,center,'zero');
A = psfMatrix(PSF);
% A  = K;
% x_true=xt(1:N,1:N);
x_true=f_true(:);  
% x_true=im2double(x_true);
% x_true = x_true(:);
btrue = A*x_true;
delta = 0.1;
e = randn(size(btrue))/norm(randn(size(btrue)));
e = norm(btrue)*delta*e;
b = btrue + e;
ddelta1 = 1.005*norm(e);
ddelta2 = 1.1*norm(e);
ddelta3 = 1.2*norm(e);
ddelta4 = 2.0*norm(e);
% b = g(:);

% 
I = speye(N);
L1=get_l(N,1);
L = [kron(I,L1); kron(L1,I)];

% 
% %  %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% options1 = HyBRset('InSolv', 'tikhonov', 'RegPar','gcv',  ...
%            'x_true', x_true(:),'Iter', maxit);
% options2 = HyBRset('InSolv','tikhonov','Iter', maxit,...
%            'RegPar','wgcv','Omega','adapt','x_true', x_true);
% options3 = HyBRset('InSolv', 'none', 'x_true', x_true(:),'Iter', maxit);
% 
% % 
% [x_out1, output1] = YangJLBDHyBR(A, L, b, maxit, options1);
% [x_out2, output2] = YangJLBDHyBR(A, L, b, maxit, options2);
% [x_out3, output3] = YangJLBDHyBR(A, L, b, maxit, options3);
% 
[Rnrm1, kkk1, err1] = YangJLBDHyBR_Discrep_2(A, L, b, x_true, maxit, ddelta1);
[Rnrm2, kkk2, err2] = YangJLBDHyBR_Discrep_2(A, L, b, x_true, maxit, ddelta2);
[Rnrm3, kkk3, err3] = YangJLBDHyBR_Discrep_2(A, L, b, x_true, maxit, ddelta3);
[Rnrm4, kkk4, err4] = YangJLBDHyBR_Discrep_2(A, L, b, x_true, maxit, ddelta4);



% [a1,b1] = min(output1.err);
% [a2,b2] = min(output2.err); 
% [a3,b3] = min(output3.err);
% 
% [a12,b12] = min(output1.err2);
% [a22,b22] = min(output2.err2); 
% [a32,b32] = min(output3.err2);
% 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure; 
% 
% semilogy(output1.err,'<b-');hold on
% semilogy(output2.err,'pm-');hold on
% semilogy(output3.err,'*r-');hold on
% title('rice with 128^2\times128^2')
% xlabel('The outer iteration')
% ylabel('Relative error')
% legend('JBDGCV','JBDWGCV','JBDQR')
% % 
% 
% figure; 
% semilogy(output2.err,'pm-');hold on
% xlabel('the number of the outer iteration')
% legend('wgcv')
% title('relative error')
% 
% figure; 
% semilogy(output3.err,'*r-');hold on
% xlabel('the number of the iteration')
% legend('none')
% title('relative error')
% 
% 
% %%%%%%%%%%%%%%%
% figure; 
% semilogy(output1.err,'<b-');hold on
% xlabel('the number of the outer iteration')
% legend('gcv')
% title('relative error')
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;
% [reg_c,rho_c,eta_c] = l_corner(output3.Rnrm,output3.Xnrm);
% plot_lc(output3.Rnrm,output3.Xnrm,'o',2);hold on
%                
% ax = axis;hold on
% loglog([min(output3.Rnrm)/100,rho_c],[eta_c,eta_c],':r',...
% [rho_c,rho_c],[min(output3.Xnrm)/100,eta_c],':r')
% title(['L-curve ',' corner at ', num2str(reg_c), ' the relative error is ',num2str(output3.err(reg_c))]);
% axis(ax);hold off

%   
% 
% figure;
% [reg_c,rho_c,eta_c] = l_corner(output3.Rnrm(1:12),output3.Xnrm(1:12));
% plot_lc(output3.Rnrm(1:12),output3.Xnrm(1:12),'o',2);hold on
%                
% ax = axis;hold on
% loglog([min(output3.Rnrm(1:12))/100,rho_c],[eta_c,eta_c],':r',...
% [rho_c,rho_c],[min(output3.Xnrm(1:12))/100,eta_c],':r')
% title(['L-curve ',' corner at ', num2str(reg_c), ' the relative error is ',num2str(output3.err(reg_c))]);
% axis(ax);hold off
% 
% 
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% figure;
% subplot(2,2,1)
% imagesc(reshape(x_true,N,N))
% colormap gray, axis image off
% title('original image')
% subplot(2,2,2)
% imagesc(reshape(x_out1(:,b1),N,N))
% colormap gray, axis image off
% title('JBDGCV')
% subplot(2,2,3) 
% imagesc(reshape(x_out2(:,b2),N,N))
% colormap gray, axis image off
% title('JBDWGCV')
% subplot(2,2,4)
% imagesc(reshape(x_out3(:,b3),N,N))
% colormap gray, axis image off
% title('JBDQR')


