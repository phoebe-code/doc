clc;
clear all;
close all;


maxit = 160;
%%%%%%%%%%%%%%%%%%% 1-D %%%%%%%%%%%%%%%%%%%%%%%%%%%
% n = 256^2;
% [A,b,x_true] = deriv2(n,2);
% noise  = randn(size(b));
% delta=1e-3;
% sigma = delta*(norm(b)/norm(noise));
% N = sigma*noise;
% b = b + N;
% L = get_l(n,1);

% %%%%%%%%%%%%%%%%%% 2-D  RestoreTools %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 N = 256;
A = blur(N,16,2);
x_true=imread('rice.png'); 
% % load mri
% % x_true = double(D(1:N,1:N,15));
%  load GaussianBlur440
% load satellite
% load AtmosphericBlur50
% A = psfMatrix(PSF);
x_true=im2double(x_true);
% % x_true=x_true(1:N,1:N);
x_true=x_true(:);
% b=g(:);
btrue = A*x_true;
delta=0.01;
e =  randn(size(btrue(:)))/norm(randn(size(btrue(:))));
b = btrue(:) + norm(btrue(:))*delta*e;
 %%%%%%%%%%%%%%%%% 2-D IRtools %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% [A, btrue, x_true, ProbInfo] = PRblurspeckle;
% [b, NoiseInfo] = PRnoise(btrue, 'gauss', delta);
%%%%%%%%%%%%%%%%%%%%%%%%% L matrix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% I = speye(N);
% L1=get_l(N,1);
% L = [kron(I,L1); kron(L1,I)];

%Example application of Qx in 2D
%%%%%%%%%%%%%%%%%%%%%2d test%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Consider the box (0,1)^2
xmin = [0 0];         %Coordinates of left corner
xmax = [1 1];         %Coordinates of right corner
nvec = [n, n];        %Number of points in grid

nu = 1.5; ell = .007;
k = @(r) matern(r,nu,ell);
%Additional parameters governing length scales. Can be used to model
%nonisotropic covariance kernels
theta = [1.0 1.0];      %For now set them as isotropic

% Build row/column of the Toeplitz matrix
Qr = createrow(xmin,xmax,nvec,k,theta);
Qfun = @(x)toeplitzproduct(x, Qr, nvec);
L = funMat(Qfun,Qfun, nvec.^2);

% 
% % %%%%%%%%%%%%%%% GSVD %%%%%%%%%%%%%%%
% 
% [U,sm,X,V,W] = cgsvd(A,L);
% [x_k,rho,eta] = tgsvd(U,sm,X,b,1:maxit);
% for i=1:maxit
%     err_k(i) = norm(L*(x_k(:,i)-x_true))/norm(L*x_true);
% end
%  
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic;
options = HyBRset('InSolv', 'none', 'x_true', x_true(:),'Iter', maxit);
[x_out, output] = YangJLBDHyBR(A, L, b, maxit, options);
toc;

tic;
[X,V] = Yanglsqr_stop(A,b,x_true,L,maxit,1);
[x_k,err_k,rho,eta] = YangfunTik(A, b,x_true,X,V,L,maxit);
toc;



[a1,b1] = min(output.err);
[a2,b2] = min(err_k);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure; 

semilogy(output.err,'*r-');hold on
semilogy(err_k,'og-');hold on
legend('JBDQR','LSQR&LSQR')
title('relative error')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
[reg_c,rho_c,eta_c] = l_corner(output.Rnrm,output.Xnrm);
plot_lc(output.Rnrm,output.Xnrm,'o',2);hold on
               
ax = axis;hold on
loglog([min(output.Rnrm)/100,rho_c],[eta_c,eta_c],':r',...
[rho_c,rho_c],[min(output.Xnrm)/100,eta_c],':r')
title(['L-curve ',' corner at ', num2str(reg_c), ' the relative error is ',num2str(output.err(reg_c))]);
axis(ax);hold off

figure;
[reg_c,rho_c,eta_c] = l_corner(rho,eta);
plot_lc(rho,eta,'o',2);hold on
               
ax = axis;hold on
loglog([min(rho)/100,rho_c],[eta_c,eta_c],':r',...
[rho_c,rho_c],[min(eta)/100,eta_c],':r')
title(['L-curve ',' corner at ', num2str(reg_c), ' the relative error is ',num2str(err_k(reg_c))]);
axis(ax);hold off



% 
% % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
subplot(2,2,1)
imagesc(reshape(x_true,N,N))
colormap gray, axis image off
title('original image')
subplot(2,2,2)
imagesc(reshape(x_out(:,b1),N,N))
colormap gray, axis image off
title('JBDQR')
subplot(2,2,3)
imagesc(reshape(x_k(:,b2),N,N))
colormap gray, axis image off
title('LSQR&LSQR')
subplot(2,2,4)
imagesc(reshape(b,N,N))
colormap gray, axis image off
title('noisy and blurred image')



