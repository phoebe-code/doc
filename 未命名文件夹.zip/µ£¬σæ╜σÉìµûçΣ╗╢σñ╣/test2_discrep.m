clc;
clear all;
close all;


maxit = 32;
% n = 1024;
% [A,btrue,x_true] = baart(n);
% % 
% % % example from AIRtools
% % % N=100;  s=N; p=2*N; n=N^2;
% delta = 1e-2;
% e =  randn(size(btrue))/norm(randn(size(btrue)));
% e = norm(btrue)*delta*e;
% b = btrue + e;
% ddelta = 1.2*norm(e);
% 
% 
% L = get_l(n,1);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
N = 128;
A = blur(N,16,2);
% xt=imread('rice.png'); 
load mri
x_true = double(D(1:N,1:N,15));
% x_true = double(D(1:N,1:N));
% load AtmosphericBlur30
% A = psfMatrix(PSF,center, 'zero');
% % A = psfMatrix(PSF);
% % A = K;
% x_true=xt(1:N,1:N);
% x_true=f_true(:);
x_true=im2double(x_true);
x_true = x_true(:);
btrue=A*x_true(:);
delta=0.05;
e =  randn(size(btrue))/norm(randn(size(btrue)));
e = norm(btrue)*delta*e;
b = btrue + e;
ddelta = 1.1*norm(e);

% b = g(:);
% 
% 
I = speye(N);
L1=get_l(N,1);
L = [kron(I,L1); kron(L1,I)];


 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
[x_out, k, err] = YangJLBDHyBR_Discrep(A, L, b, x_true, maxit, ddelta,e);

% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure;
subplot(1,2,1)
imagesc(reshape(x_true,N,N))
colormap gray, axis image off
title('original image')
subplot(1,2,2)
imagesc(reshape(x_out,N,N))
colormap gray, axis image off
title('gcv')
