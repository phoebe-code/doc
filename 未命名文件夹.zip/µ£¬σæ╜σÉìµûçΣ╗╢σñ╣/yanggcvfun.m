function G = yanggcvfun(lambda,s2,beta,delta0,mn,Omega)

% Auxiliary routine for gcv.  PCH, IMM, Feb. 24, 2008.

% Note: f = 1 - filter-factors.
 f1 = lambda^2./(s2 + lambda^2);
 f =((1- Omega)*s2+lambda^2)./(s2 + lambda^2);

G = (norm(f1.*beta)^2 + delta0)/(mn + sum(f))^2;