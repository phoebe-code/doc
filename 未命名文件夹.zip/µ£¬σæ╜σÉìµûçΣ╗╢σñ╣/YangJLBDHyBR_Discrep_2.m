function [x_out, k, err] = YangJLBDHyBR_Discrep_2(A, L, b, xtrue, maxit,ddelta)


% A = sparse(A);
[~,n] = size(L);
[BB, ~, UU, ~, VV, bbeta]=JointBid(A,L,b,maxit,1);

vector = (bbeta*eye(size(UU(:,1:2),2),1));
f = BB(1:2,1:1)\vector;
Rnrm(1) = norm(BB(1:2,1:1)*f-vector);



% vector = (bbeta*eye(size(UU(:,1:3),2),1));
% f = BB(1:3,1:2)\vector;
% Rnrm(2) = norm(BB(1:3,1:2)*f-vector);
% norm(Rnrm(2))
nx = norm(L*xtrue);

% if(Rnrm(1)<ddelta )   
%    d = VV(:,1)*f;
%    x_out = lsqr(@(z,tflag)afun(z,A,L,tflag),d,1e-6,n);
%    err = norm(L*(x_out-xtrue))/lnx;
%    k=1;
% else
    k=1;
    while(Rnrm(k)>ddelta)
        k=1+k;
        U = UU(:,1:k+1); B = BB(1:k+1,1:k);
        vector = (bbeta*eye(size(U,2),1));
        f = B\vector;
        Rnrm(k) = norm(B*f-vector);
    end
% end
f = BB(1:k+1,1:k)\(bbeta*eye(size(UU(:,1:k+1),2),1));
d = VV(:,1:k)*f;
x_out = lsqr(@(z,tflag)afun(z,A,L,tflag),d,1e-6,n);
err = norm(L*(x_out-xtrue))/nx;
end




function y =afun(z,A,B,transp_flag)
if strcmp(transp_flag,'transp')   % y = (A(I_n-BB^T))' * z;
    m = size(A,1);
    p = size(B,1);
    s = A'*z(1:m);
    t = B'*z(m+1:m+p);
    y = s + t;
elseif strcmp(transp_flag,'notransp') % y = (A(I_n-BB^T)) * z;
    s = A*z;
    t= B*z;
    y = [s;t];
    
end
end










