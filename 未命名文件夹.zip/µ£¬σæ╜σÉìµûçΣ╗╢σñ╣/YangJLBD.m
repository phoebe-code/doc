function [U, Uhat, B, Bbar, Bhat, V, flag, relres, iter] = YangJLBD(A, L, U, Uhat, B, Bbar, Bhat, V, reorth)
%
% [U, Uhat, B, Bhat, V, flag,relres,iter] = YangJLBD(A, L, U, Uhat, B, Bhat, V)
%
%  Perform one step of Lanczos bidiagonalization with or without
%  reorthogonalization, WITHOUT preconditioner here.
%
% Input:
%          A - matrix
%       U, V - accumulation of vectors
%          B - bidiagonal matrix
%    options - structure from HyBR (see HyBRset)
%
% Output:
%       U, V - updated "orthogonal" matrix
%          B - updated bidiagonal matrix
%
%  Refs:
%   [1] Paige and Saunders, "LSQR an algorithm for sparse linear
%       equations an sparse least squares", ACM Trans. Math Software,
%       8 (1982), pp. 43-71.
%   [2] Bjorck, Grimme and Van Dooren, "An implicit shift bidiagonalization
%       algorithm for ill-posed systems", BIT 34 (11994), pp. 520-534.
%
%   J.Chung and J. Nagy 3/2007

% Determine if we need to do reorthogonalization or not.
% % n=size(A,1);

m = size(U,1);
p = size(L,1);
k = size(Bbar,1)+1;
M = [A; L];
utild = [U(:,k); zeros(p,1)];
[Qu, flag,relres,iter] = lsqr(M,utild,1e-8,m);
Qu = M*Qu;
if k == 1
    v = Qu;
    alpha = norm(v);
    v = v / alpha;
    uhat = v(m+1:m+p);
    alphahat = norm(uhat);
    uhat = uhat / alphahat;
    
    
    if (reorth == 0)
        u = v(1:m) - alpha * U(:,k);
    elseif (reorth == 1)
        u = v(1:m) - alpha * U(:,k);
        u = u - U *(U' * u);
    elseif (reorth == 2)
        u = v(1:m) - alpha * U(:,k);
        u = u - U * (U' * u);
        u = u - U * ( U' * u);
    end
    beta = norm(u);
    u = u / beta;
    
    V(:,k) = v;
    U(:,k+1) = u;
    Uhat(:,k) = uhat;
    B(k,k) = alpha;
    B(k+1,1) = beta;
    Bhat(k,k) = alphahat;
    Bbar(k,k) = alphahat;
else
    
    
    if (reorth == 0)
        v = Qu - B(k, k-1)*V(:,k-1);
    elseif(reorth == 1)
        v = Qu - B(k, k-1)*V(:,k-1);
        for j=1:k-1, v = v - (V(:,j)'*v)*V(:,j); end
%         v = v - V * V' * v;
    elseif (reorth == 2)
        v = Qu - B(k, k-1)*V(:,k-1);
        for j=1:k-1, v = v - (V(:,j)'*v)*V(:,j); end
        for j=1:k-1, v = v - (V(:,j)'*v)*V(:,j); end
%         v = v - V * V' * v;
%         v = v - V * V' * v;
    end
    alpha = norm(v);
    v = v / alpha;
    
    betahat = (alpha*B(k,k-1)) / Bhat(k-1,k-1);
    if(mod(k,2)==0)
        betabar = -betahat;
    else
        betabar = betahat;
    end
    
    
    if(mod(k,2)==0)
        vv = -v(m+1:m+p);
    else
        vv = v(m+1:m+p);
    end
    
    if (reorth == 0)
        uhat = vv - betahat * Uhat(:,k-1);
    elseif (reorth == 1)
        uhat = vv - betahat * Uhat(:,k-1);
        for j=1:k-1, uhat = v - (Uhat(:,j)'*uhat)*Uhat(:,j); end
%         uhat = uhat - Uhat * Uhat' * uhat;
    elseif (reorth == 2)
        uhat = vv - betahat * Uhat(:,k-1);
        for j=1:k-1, uhat = uhat - (Uhat(:,j)'*uhat)*Uhat(:,j); end
        for j=1:k-1, uhat = uhat - (Uhat(:,j)'*uhat)*Uhat(:,j); end
%         uhat = uhat - Uhat * Uhat' * uhat;
%         uhat = uhat - Uhat * Uhat' * uhat;
    end
    alphahat = norm(uhat);
    uhat = uhat / alphahat;
    if (mod(k,2)==0)
        alphabar = -alphahat;
    else
        alphabar = alphahat;
    end
    
    if (reorth == 0)
        u = v(1:m) - alpha * U(:,k);
    elseif (reorth == 1)
        u = v(1:m) - alpha * U(:,k);
        for j=1:k-1, u = u - (U(:,j)'*u)*U(:,j); end
%         u = u - U * U' * u;
    elseif (reorth == 2)
        u = v(1:m) - alpha * U(:,k);
        for j=1:k-1, u = u - (U(:,j)'*u)*U(:,j); end
        for j=1:k-1, u = u - (U(:,j)'*u)*U(:,j); end
%         u = u - U * U' * u;
%         u = u - U * U' * u;
    end
    beta = norm(u);
    u = u / beta;
    
    
    V(:,k) = v;
    U(:,k+1) = u;
    Uhat(:,k) = uhat;
    B(k,k) = alpha;
    B(k+1,k) = beta;
    Bhat(k,k) = alphahat;
    Bhat(k-1,k) = betahat;
    Bbar(k,k) = alphabar;
    Bbar(k-1,k) = betabar;
end


