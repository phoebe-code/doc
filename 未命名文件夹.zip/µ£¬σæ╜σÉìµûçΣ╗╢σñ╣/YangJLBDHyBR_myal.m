function output = YangJLBDHyBR_myal(A, L, b, x_true, maxiter,reorth)
%
%
M = [A; L];

n = size(A,2);
nrmtrue = norm(L*x_true);
beta = norm(b); 
U(:,1) = b / beta;
B = []; Bbar = []; Bhat = []; Uhat = [];  V = [];

for i = 1:maxiter+1
  
    [U, Uhat, B, Bbar, Bhat, V, flag, relres, iter] = YangJLBD(A, L, U, Uhat, B, Bbar, Bhat, V,reorth);
    vector = (beta*eye(size(U,2),1));
    
    f = B(1:i+1,1:i) \ vector;
    y = V*f;
    x = lsqr(M, y, 1e-8, n);

%     output.UU(i)  = norm(eye(i+1)-U'*U);
%     output.VV(i)  = norm(eye(i)-V'*V);
%     output.Uhat(i) = norm(eye(i)-Uhat'*Uhat);
    output.err(i,1) = norm(L*(x-x_true))/nrmtrue;
%     output.res(i,1) = norm(b - A*x);
%     output.rres(i,1) = norm(B(1:i+1,1:i)*f - vector);
%     output.sol(i,1) = norm(L*x);
    output.B = B;
    output.Bbar = Bbar;
    output.flag(i,1) = flag;
    output.relres(i,1) = relres;
    output.iter(i,1) = iter;
    
end
end







