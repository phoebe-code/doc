function [ flag, relres, iter,output] = YangJLBDHyBR_myl(A, L, b, x_true, maxiter)
%
%
[p,m] = size(L);
nrmtrue = norm(L*x_true);
beta = norm(b); U = b / beta;

B = []; Bbar = []; Bhat = []; Uhat = [];  V = [];

for i = 1:maxiter+1
    
    [U, Uhat, B, Bbar, Bhat, V, flag, relres, iter(i)] = YangJLBD(A, L, U, Uhat, B, Bbar, Bhat, V);
    vector = (beta*eye(size(U,2),1));
    
    if i>2
        f = B \ vector;
       
        output.Enrm(i-1,1) = norm(Uhat*Bbar*f-L*x_true)/nrmtrue;
        output.Rnrm(i-1,1) = norm(b - U*B*f);
        output.Xnrm(i-1,1) = norm(Uhat*Bbar*f);
        output.B = B;
        output.Bbar = Bbar;
    end
end
end







