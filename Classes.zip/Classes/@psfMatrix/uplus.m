function A  = uplus( A )
%
%  Overload uplus for a psfMatrix object.
%  Given A, this retruns +A.
%

%  K. Lee  1/18/02

A=A;
