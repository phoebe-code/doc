function display(k)
%
%     prints the elements of k.a, k.b and k.c
%

disp (sprintf ('a ='));
disp(k.a);
disp (sprintf ('b ='));
disp(k.b);
disp (sprintf ('c ='));
disp(k.c);
