function M = uplus(K)
%
%     +K = K
%

M = K;
