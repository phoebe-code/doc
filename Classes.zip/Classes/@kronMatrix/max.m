function x = max(k)
%  kronMatrix max(k)
%
%

x = kronMatrix(max(k.a), max(k.b));
